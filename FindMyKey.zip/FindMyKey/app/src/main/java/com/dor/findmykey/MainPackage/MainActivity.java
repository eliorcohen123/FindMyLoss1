package com.dor.findmykey.MainPackage;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.dor.findmykey.R;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private EditText userNameWrite, phoneWrite, placeWrite, detailsWrite, myPlace;
    private Firebase firebase;
    private ListView listViewLost, listViewSearch;
    private ArrayAdapter arrayAdapterLost, arrayAdapterSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userNameWrite = findViewById(R.id.userNameWrite);
        phoneWrite = findViewById(R.id.phoneWrite);
        placeWrite = findViewById(R.id.placeWrite);
        detailsWrite = findViewById(R.id.detailsWrite);
        myPlace = findViewById(R.id.myPlace);

        findViewById(R.id.btnPlace).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String myStrPlace = myPlace.getText().toString();
                SharedPreferences.Editor editor = getSharedPreferences("textPlace", MODE_PRIVATE).edit();
                editor.putString("idPlace", myStrPlace);
                editor.apply();

                finish();
                startActivity(getIntent());
            }
        });

        Firebase.setAndroidContext(this);
        firebase = new Firebase("https://findmykey-fe348.firebaseio.com/");

        findViewById(R.id.btnWrite).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date = new Date();
                String time = date.toString();
                firebase.child(time).child("userName").setValue(userNameWrite.getText().toString());
                firebase.child(time).child("phone").setValue(phoneWrite.getText().toString());
                firebase.child(time).child("place").setValue(placeWrite.getText().toString().toLowerCase());
                firebase.child(time).child("details").setValue(detailsWrite.getText().toString());
            }
        });

        listViewLost = findViewById(R.id.myListLost);
        arrayAdapterLost = new ArrayAdapter(this, android.R.layout.simple_list_item_1);
        listViewLost.setAdapter(arrayAdapterLost);
        listViewSearch = findViewById(R.id.myListSearch);
        arrayAdapterSearch = new ArrayAdapter(this, android.R.layout.simple_list_item_1);
        listViewSearch.setAdapter(arrayAdapterSearch);

        firebase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                arrayAdapterLost.clear();
                arrayAdapterSearch.clear();
                try {
                    SharedPreferences prefs = getSharedPreferences("textPlace", MODE_PRIVATE);
                    String idMyPlace = prefs.getString("idPlace", "");
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        arrayAdapterLost.add("Name: " + snapshot.child("userName").getValue() +
                                "\n" + "Phone: " + snapshot.child("phone").getValue() +
                                "\n" + "Place: " + snapshot.child("place").getValue().toString().toLowerCase() +
                                "\n" + "Details: " + snapshot.child("details").getValue());
                        if (snapshot.child("place").getValue().equals(idMyPlace)) {
                            arrayAdapterSearch.add("Name: " + snapshot.child("userName").getValue() +
                                    "\n" + "Phone: " + snapshot.child("phone").getValue() +
                                    "\n" + "Place: " + snapshot.child("place").getValue().toString().toLowerCase() +
                                    "\n" + "Details: " + snapshot.child("details").getValue());
                        }
                    }
                } catch (Exception e) {

                }
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }

}
